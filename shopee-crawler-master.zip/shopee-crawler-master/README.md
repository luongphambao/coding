# This is practice to scrape Shopee seller page's categories using python3.

Make sure your chrome version is support headless.

## How to run

~~~bash
# active python virtual env
source env/bin/activate
# run project
bin/gocrawler
~~~